// ex13.js
function delayedHello() {
    setTimeout(() => {
        console.log("Hello after 1 second");
    }, 1000);
}

// Teste:
 delayedHello(); // Após 1s: "Hello after 1 second"