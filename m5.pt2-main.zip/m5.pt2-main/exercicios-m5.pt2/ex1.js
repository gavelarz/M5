function validateNumber(n) {
    if (typeof n === 'number') {
        return true;
    } else {
        throw new Error('O parâmetro deve ser um número.');
    }
}

//Exemplos de uso (teste no console):
 console.log(validateNumber(5)); // true
 //validateNumber('5'); // Lança erro: "O parâmetro deve ser um número."