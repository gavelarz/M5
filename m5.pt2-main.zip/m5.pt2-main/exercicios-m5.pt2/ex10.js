// ex10.js
function formatMessage(msg, formatter) {
    return formatter(msg);
}

// Teste:
 console.log(formatMessage('hello', str => str.toUpperCase())); // "HELLO"