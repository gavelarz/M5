// ex11.js
function fakeRequest(url, callback) {
    setTimeout(() => {
        callback(null, "OK");
    }, 1000);
}

// Teste:
 fakeRequest('http://example.com', (err, data) => console.log(data)); // Após 1s: "OK"