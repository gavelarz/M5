// ex4.js
function countDown(n) {
    if (n > 0) {
        console.log(n);
        countDown(n - 1);
    }
}

// Teste:
 countDown(5); // Imprime 5, 4, 3, 2, 1