// ex15.js
// Reescrevendo function sum(a, b) { return a + b; } como arrow function
const sum = (a, b) => a + b;

// Teste:
 console.log(sum(3, 4)); // 7