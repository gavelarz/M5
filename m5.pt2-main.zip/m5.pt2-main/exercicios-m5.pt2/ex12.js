// ex12.js
function fakeRequest(url, callback) {
    setTimeout(() => {
        callback(null, "OK");
    }, 1000);
}

// Encadeamento de três chamadas
fakeRequest('url1', (err, data) => {
    console.log('Primeira chamada:', data);
    fakeRequest('url2', (err, data) => {
        console.log('Segunda chamada:', data);
        fakeRequest('url3', (err, data) => {
            console.log('Terceira chamada:', data);
        });
    });
});

// Teste: Imprime as mensagens após 1s cada (total ~3s)