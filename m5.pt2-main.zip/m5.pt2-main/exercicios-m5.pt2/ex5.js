// ex5.js
function applyFunction(fn, value) {
    return fn(value);
}

// Teste:
 console.log(applyFunction(x => x * 2, 5)); // 10