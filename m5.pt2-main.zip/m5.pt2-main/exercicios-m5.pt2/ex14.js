// ex14.js
function countToFive() {
    let count = 1;
    const intervalId = setInterval(() => {
        console.log(count);
        if (count === 5) {
            clearInterval(intervalId);
        }
        count++;
    }, 1000);
}

// Teste:
 countToFive(); // Conta de 1 a 5 a cada 1s e para