// ex9.js
function calculate(a, b, callback) {
    return callback(a, b);
}

// Teste:
 console.log(calculate(5, 3, (x, y) => x + y)); // 8