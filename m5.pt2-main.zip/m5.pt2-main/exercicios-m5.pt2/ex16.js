// ex16.js
const obj = {
    name: 'João',
    // Função tradicional: this se refere ao objeto
    sayHiTraditional: function() {
        return "Olá, " + this.name;
    },
    // Arrow function: this é léxico (herda do escopo externo, não do objeto)
    sayHiArrow: () => {
        return "Olá, " + this.name;  // this aqui é undefined ou do escopo global
    }
};

// Teste:
console.log(obj.sayHiTraditional()); // "Olá, João" (this é obj)
console.log(obj.sayHiArrow()); // "Olá, undefined" (this não é obj, é léxico)

// Análise: Arrow functions não têm seu próprio this; elas usam o this do contexto onde foram definidas.
// Em objetos, isso pode causar comportamentos inesperados, pois this não aponta para o objeto.