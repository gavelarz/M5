// ex8.js
const user = {
    name: 'João',
    sayHi: function() {
        return "Olá, " + this.name;
    }
};

// Teste:
 console.log(user.sayHi()); // "Olá, João"