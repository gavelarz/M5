// ex6.js
const operations = [
    (a, b) => a + b,  // Soma
    (a, b) => a - b,  // Subtração
    (a, b) => a * b   // Multiplicação
];

// Itere sobre o array aplicando aos números 4 e 2
operations.forEach(op => {
    console.log(op(4, 2));
});

// Teste: Imprime 6, 2, 8