// ex7.js
const greet = function(name) {
    return "Olá, " + name;
};

// Teste:
 console.log(greet('João')); // "Olá, João"