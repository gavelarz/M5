// ex2.js
function validateUser(name, age) {
    if (typeof name === 'string' && name.trim() !== '' && typeof age === 'number' && age >= 0) {
        return true;
    } else {
        return false;
    }
}

// Teste:
 console.log(validateUser('João', 25)); // true
 console.log(validateUser('', 25)); // false
 console.log(validateUser('João', -5)); // false